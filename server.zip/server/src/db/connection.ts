import { Sequelize } from "sequelize";


const sequelize = new Sequelize('databaseesika', 'root', '', {
    host: 'localhost',
    dialect: 'mysql'
  });

  export default sequelize;