import { DataTypes } from 'sequelize';
import db from '../db/connection';

const Marca = db.define('marca', {
  id_marca: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  nombre: {
    type: DataTypes.STRING(100)
  }
}, {
  timestamps: false,
  tableName: 'marca'
});

export default Marca;
