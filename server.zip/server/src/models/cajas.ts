// models/cajas.ts

import { DataTypes } from 'sequelize';
import db from '../db/connection';

const Cajas = db.define('cajas', {
    caja_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    usuario_id	: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    nombre: {
        type: DataTypes.STRING(100)
    },
    ubicacion: {
        type: DataTypes.STRING(100)
    },
    efectivoTotal: {
        type: DataTypes.DECIMAL(10, 2)
    }
}, {
    timestamps: false,
    tableName: 'caja'
});

export default Cajas;
