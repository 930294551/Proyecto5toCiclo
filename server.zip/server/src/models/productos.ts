import { DataTypes } from 'sequelize';
import db from '../db/connection';

const Productos = db.define('productos', {
    producto_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    stock_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    nombre: {
        type: DataTypes.STRING(100)
    },
    categoria_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    id_marca: {
        type: DataTypes.INTEGER
    },
    modelo: {
        type: DataTypes.STRING(50)
    },
    imagen_url: {
        type: DataTypes.STRING(500)
    }
}, {
    timestamps: false,
    tableName: 'producto'
});

export default Productos;

