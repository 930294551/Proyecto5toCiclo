// models/detalle_registro_ventas.ts

import { DataTypes } from 'sequelize';
import db from '../db/connection';

const DetalleRegistroVentas = db.define('detalles_registro_ventas', {
    detalle_registro_ventas_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    registro_ventas_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'registro_ventas',
            key: 'registro_ventas_id'
        }
    },
    producto_nombre: {
        type: DataTypes.STRING(500),
        allowNull: false,
    },
    cantidad: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    precio_unitario: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    },
    precio_total: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    }
}, {
    timestamps: false,
    tableName: 'detalles_registro_ventas'
});

export default DetalleRegistroVentas;
