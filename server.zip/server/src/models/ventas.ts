import { DataTypes } from 'sequelize';
import db from '../db/connection';

const Ventas = db.define('ventas', {
    venta_id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    precio_id: {
      type: DataTypes.INTEGER
    },
    campania_id: {
      type: DataTypes.INTEGER
    },
    producto_id: {
      type: DataTypes.INTEGER
    },
    descripcion: {
      type: DataTypes.STRING(255),
      allowNull: true
    },
    cantidad: {
      type: DataTypes.INTEGER
    },
    foto_producto: {
      type: DataTypes.STRING(400),
      allowNull: true
    }
  }, {
    timestamps: false,
    tableName: 'venta'
  });
  

export default Ventas;
