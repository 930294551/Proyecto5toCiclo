// models/precios.ts

import { DataTypes } from 'sequelize';
import db from '../db/connection';

const Precio = db.define('precio', {
    precio_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    costo: {
        type: DataTypes.DECIMAL(20, 2)
    },
    precio: {
        type: DataTypes.DECIMAL(18, 2)
    }
}, {
    timestamps: false,
    tableName: 'precio'
});

export default Precio;
