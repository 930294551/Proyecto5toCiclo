import { DataTypes } from "sequelize";
import db from "../db/connection";

const Campania = db.define(
  "campania",
  {
    campania_id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    fecha_inicio: {
      type: DataTypes.DATE,
    },
    fecha_final: {
      type: DataTypes.DATE,
    },
    numero_campania: {
      type: DataTypes.INTEGER,
    }
  },
  {
    timestamps: false,
    tableName: "campania",
  }
);
export default Campania;
