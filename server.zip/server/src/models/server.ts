import express, { Application, Request, Response } from "express";
import cors from "cors";
import multer from "multer";
import path from "path";
import fs from "fs";
import routesClientes from "../routes/clientes";
import routesProductos from "../routes/productos";
import routesUsuarios from "../routes/usuarios";
import routesVentas from "../routes/ventas";
import routesCajas from "../routes/cajas";
import routesCategorias from "../routes/categorias";
import routesPrecios from "../routes/precio";
import routesStocks from "../routes/stocks";
import routesUnidadesMedida from "../routes/unidadesMedida";
import routesMarca from "../routes/marca";
import routesCampania from "../routes/campania"; 
import routesDetalleRegistroVentas from "../routes/detalle_registro_ventas"; 
import routesRegistroVenta from "../routes/registro_ventas"; 
import db from "../db/connection";

class Server {
  private app: Application;
  private port: string;

  constructor() {
    this.app = express();
    this.port = process.env.PORT || "3001";
    this.listen();
    this.middlewares();
    this.routes();
    this.dbConnect();
  }

  listen() {
    this.app.listen(this.port, () => {
      console.log(`Aplicacion corriendo en el puerto ${this.port}`);
    });
  }

  routes() {
    this.app.get("/", (req: Request, res: Response) => {
      res.json({
        msg: "API SE ESTA EJECUTANDO",
      });
    });

    const uploadDir = path.join(__dirname, "../../../vista/src/assets");
    const storage = multer.diskStorage({
      destination: (req, file, cb) => {
        cb(null, path.join(__dirname, "../../../vista/src/assets"));
      },
      filename: (req, file, cb) => {
        cb(null, file.originalname);
      },
    });
    const upload = multer({ storage: storage });
    this.app.use(
      express.static(path.join(__dirname, "../../../vista/src/assets"))
    );
    this.app.post("/upload", upload.single("file"), (req, res) => {
      if (!req.file) {
        console.log("No se ha seleccionado ningún archivo");
        return res
          .status(400)
          .json({ message: "No se ha seleccionado ningún archivo" });
      }
      console.log("Archivo subido con éxito:", req.file.filename);
      res
        .status(200)
        .json({
          message: "Archivo subido con éxito",
          filename: req.file.filename,
        });
    });

    this.app.use("/api/clientes", routesClientes);
    this.app.use("/api/productos", routesProductos);
    this.app.use("/api/usuarios", routesUsuarios);
    this.app.use("/api/ventas", routesVentas);
    this.app.use("/api/marca", routesMarca);
    this.app.use("/api/cajas", routesCajas);
    this.app.use("/api/categorias", routesCategorias);
    this.app.use("/api/precio", routesPrecios);
    this.app.use("/api/stock", routesStocks);
    this.app.use("/api/unidadesMedida", routesUnidadesMedida);
    this.app.use("/api/campania", routesCampania);
    this.app.use("/api/registroVentas", routesRegistroVenta);
    this.app.use("/api/detalleRegistroVentas", routesDetalleRegistroVentas);
  }

  middlewares() {
    this.app.use(express.json());
    this.app.use(cors());
  }

  async dbConnect() {
    try {
      await db.authenticate();
      console.log("Base de datos conectada");
    } catch (error) {
      console.log(error);
      console.log("Error al conectarse a la base de datos");
    }
  }
}

export default Server;
