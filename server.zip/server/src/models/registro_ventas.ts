// models/registro_ventas.ts

import { DataTypes } from 'sequelize';
import db from '../db/connection';

const RegistroVentas = db.define('registro_ventas', {
    registro_ventas_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    nombreCliente: {
        type: DataTypes.STRING(500),
        allowNull: false,
    },
    usuarioAtendiendo: {
        type: DataTypes.STRING(500),
        allowNull: false,
    },
    fecha: {
        type: DataTypes.DATE,
        allowNull: false
    },
    total: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    }
}, {
    timestamps: false,
    tableName: 'registro_ventas'
});

export default RegistroVentas;
