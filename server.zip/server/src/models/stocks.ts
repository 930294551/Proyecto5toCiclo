// models/stock.ts

import { DataTypes } from 'sequelize';
import db from '../db/connection';

const Stock = db.define('stock', {
    stock_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    unidad_medida_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    cantidad: {
        type: DataTypes.INTEGER
    }
}, {
    timestamps: false,
    tableName: 'stock'
});

export default Stock;
