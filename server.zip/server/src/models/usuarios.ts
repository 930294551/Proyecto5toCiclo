import { Model, DataTypes } from 'sequelize';
import db from '../db/connection';

interface UsuarioAttributes {
  usuario_id: number;
  nombres: string;
  apellidos: string;
  email: string;
  nombreUsuario: string;
  clave: string;
  tipo: string;
  linkFoto?: string | null;
  dni: number;
  genero: string;
  fecha_nacimiento: Date;
  celular: number;
}

class Usuario extends Model<UsuarioAttributes> implements UsuarioAttributes {
  public usuario_id!: number;
  public nombres!: string;
  public apellidos!: string;
  public email!: string;
  public nombreUsuario!: string;
  public clave!: string;
  public tipo!: string;
  public linkFoto!: string | null;
  public dni!: number;
  public genero!: string;
  public fecha_nacimiento!: Date;
  public celular!: number;
}

Usuario.init({
  usuario_id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  nombres: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  apellidos: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  email: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  nombreUsuario: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  clave: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  tipo: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  linkFoto: {
    type: DataTypes.STRING(1025),
    allowNull: true
  },
  dni: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  genero: {
    type: DataTypes.STRING(50),
    allowNull: false
  },
  fecha_nacimiento: {
    type: DataTypes.DATE,
    allowNull: false
  },
  celular: {
    type: DataTypes.INTEGER,
    allowNull: false
  }
}, {
  sequelize: db,
  modelName: 'Usuario',
  timestamps: false,
  tableName: 'usuario' 
});

export default Usuario;
