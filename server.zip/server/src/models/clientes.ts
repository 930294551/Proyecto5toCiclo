import { DataTypes } from 'sequelize';
import db from '../db/connection';

const Clientes = db.define('clientes', {
    cliente_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    dni: {
        type: DataTypes.STRING(25)
    },
    provincia: {
        type: DataTypes.STRING(50)
    },
    ciudad: {
        type: DataTypes.STRING(50)
    },
    direccion: {
        type: DataTypes.STRING(100)
    },
    usuario_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    }
}, {
    timestamps: false,
    tableName: 'cliente'
});

export default Clientes;
