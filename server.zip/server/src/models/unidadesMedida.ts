// models/unidadesMedida.ts

import { DataTypes } from 'sequelize';
import db from '../db/connection';

const UnidadesMedida = db.define('unidadesMedida', {
    unidad_medida_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    unidadMedida: {
        type: DataTypes.STRING(10)
    }
}, {
    timestamps: false,
    tableName: 'unidad_medida'
});

export default UnidadesMedida;
