import { Router } from 'express';   
import { deleteClientes, getCliente, getClientes, postClientes, updateClientes } from '../controllers/clientes';

const router = Router();

router.get('/', getClientes);
router.get('/:id', getCliente);
router.delete('/:id', deleteClientes);
router.post('/', postClientes);
router.put('/:id', updateClientes);

export default router;