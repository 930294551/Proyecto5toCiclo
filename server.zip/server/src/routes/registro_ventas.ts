import { Router } from 'express';
import {
  deleteRegistroVenta,
  getRegistroVenta,
  getRegistroVentas,
  postRegistroVenta,
  updateRegistroVenta,
} from '../controllers/registro_ventas';

const router = Router();

router.get('/', getRegistroVentas);
router.get('/:id', getRegistroVenta);
router.delete('/:id', deleteRegistroVenta);
router.post('/', postRegistroVenta);
router.put('/:id', updateRegistroVenta);

export default router;
