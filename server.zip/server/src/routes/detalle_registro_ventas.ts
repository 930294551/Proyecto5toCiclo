import { Router } from 'express';
import {
  deleteDetalleRegistroVenta,
  getDetalleRegistroVenta,
  getDetalleRegistroVentas,
  postDetalleRegistroVenta,
  updateDetalleRegistroVenta,
} from '../controllers/detalle_registro_ventas';

const router = Router();

router.get('/', getDetalleRegistroVentas);
router.get('/:id', getDetalleRegistroVenta);
router.delete('/:id', deleteDetalleRegistroVenta);
router.post('/', postDetalleRegistroVenta);
router.put('/:id', updateDetalleRegistroVenta); 

export default router;
