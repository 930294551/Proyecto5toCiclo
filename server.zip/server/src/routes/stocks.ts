// routes/stock.ts

import { Router } from 'express';   
import { deleteStock, getStock, getStocks, postStock, updateStock } from '../controllers/stocks'; 

const router = Router();

router.get('/', getStocks);
router.get('/:id', getStock);
router.delete('/:id', deleteStock); 
router.post('/', postStock); 
router.put('/:id', updateStock);

export default router;
