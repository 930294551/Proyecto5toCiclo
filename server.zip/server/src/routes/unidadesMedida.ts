// routes/unidadesMedida.ts

import { Router } from 'express';   
import { deleteUnidadMedida, getUnidadMedida, getUnidadesMedida, postUnidadMedida, updateUnidadMedida } from '../controllers/unidadesMedida'; 

const router = Router();

router.get('/', getUnidadesMedida);
router.get('/:id', getUnidadMedida);
router.delete('/:id', deleteUnidadMedida); 
router.post('/', postUnidadMedida); 
router.put('/:id', updateUnidadMedida);

export default router;
