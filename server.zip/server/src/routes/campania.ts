// routes/campanias.ts
import { Router } from "express";
import {
  deleteCampania,
  getCampania,
  getCampanias,
  postCampania,
  updateCampania,
} from "../controllers/campania";

const router = Router();

router.get("/", getCampanias);
router.get("/:id", getCampania);
router.delete("/:id", deleteCampania);
router.post("/", postCampania);
router.put("/:id", updateCampania);

export default router;