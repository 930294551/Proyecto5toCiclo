// routes/cajas.ts

import { Router } from 'express';   
import { deleteCaja, getCaja, getCajas, postCaja, updateCaja } from '../controllers/cajas'; 

const router = Router();

router.get('/', getCajas);
router.get('/:id', getCaja);
router.delete('/:id', deleteCaja); 
router.post('/', postCaja); 
router.put('/:id', updateCaja);

export default router;
