import { Router } from 'express';
import { deleteUsuario, getUsuario, getUsuarios, login, postUsuario, updateUsuario, getUsuarioPorId, getUsuarioByNameUser } from '../controllers/usuarios'; 

const router = Router();

router.get('/', getUsuarios);
router.get('/:correo', getUsuario);
router.get('/id/:id', getUsuarioPorId);
router.get('/nameuser/:nameuser', getUsuarioByNameUser);
router.delete('/:correo', deleteUsuario); 
router.post('/', postUsuario); 
router.put('/:id', updateUsuario);
router.post('/login', login);

export default router;
