// routes/precios.ts

import { Router } from 'express';   
import { deletePrecio, getPrecio, getPrecios, postPrecio, updatePrecio } from '../controllers/precio'; 

const router = Router();

router.get('/', getPrecios);
router.get('/:id', getPrecio);
router.delete('/:id', deletePrecio); 
router.post('/', postPrecio); 
router.put('/:id', updatePrecio);

export default router;
