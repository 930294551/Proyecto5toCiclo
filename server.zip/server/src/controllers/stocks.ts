// controllers/stock.ts

import { Request, Response } from 'express';
import Stock from '../models/stocks';

export const getStocks = async (req: Request, res: Response) => {
    const stocks = await Stock.findAll();
    res.json(stocks);
};

export const getStock = async (req: Request, res: Response) => {
    const { id } = req.params;
    const stock = await Stock.findByPk(id);

    if (stock) {
        res.json(stock);
    } else {
        res.status(404).json({
            msg: `No existe un stock con el id ${id}`
        });
    }
};

export const deleteStock = async (req: Request, res: Response) => {
    const { id } = req.params;
    const stock = await Stock.findByPk(id);

    if (!stock) {
        res.status(404).json({
            msg: `No existe un stock con el id ${id}`
        });
    } else {
        await stock.destroy();
        res.json({
            msg: 'El stock fue eliminado con éxito'
        });
    }
};

export const postStock = async (req: Request, res: Response) => {
    const { body } = req;

    try {
        await Stock.create(body);
        res.json({
            msg: `El stock fue agregado con éxito`
        });
    } catch (error) {
        console.log(error);
        res.json({
            msg: `Ocurrió un error al agregar el stock, comuníquese con soporte`
        });
    }
};

export const updateStock = async (req: Request, res: Response) => {
    const { body } = req;
    const { id } = req.params;

    try {
        const stock = await Stock.findByPk(id);
        if (stock) {
            await stock.update(body);
            res.json({
                msg: 'El stock fue actualizado con éxito'
            });
        } else {
            res.status(404).json({
                msg: `No existe un stock con el id ${id}`
            });
        }
    } catch (error) {
        console.log(error);
        res.json({
            msg: `Ocurrió un error al actualizar el stock, comuníquese con soporte`
        });
    }
};
