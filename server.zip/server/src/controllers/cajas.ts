// controllers/cajas.ts

import { Request, Response } from 'express';
import Cajas from '../models/cajas';

export const getCajas = async (req: Request, res: Response) => {
    const cajas = await Cajas.findAll();
    res.json(cajas);
};

export const getCaja = async (req: Request, res: Response) => {
    const { id } = req.params;
    const caja = await Cajas.findByPk(id);

    if (caja) {
        res.json(caja);
    } else {
        res.status(404).json({
            msg: `No existe una caja con el id ${id}`
        });
    }
};

export const deleteCaja = async (req: Request, res: Response) => {
    const { id } = req.params;
    const caja = await Cajas.findByPk(id);

    if (!caja) {
        res.status(404).json({
            msg: `No existe una caja con el id ${id}`
        });
    } else {
        await caja.destroy();
        res.json({
            msg: 'La caja fue eliminada con éxito'
        });
    }
};

export const postCaja = async (req: Request, res: Response) => {
    const { body } = req;

    try {
        await Cajas.create(body);
        res.json({
            msg: `La caja fue agregada con éxito`
        });
    } catch (error) {
        console.log(error);
        res.json({
            msg: `Ocurrió un error al agregar la caja, comuníquese con soporte`
        });
    }
};

export const updateCaja = async (req: Request, res: Response) => {
    const { body } = req;
    const { id } = req.params;

    try {
        const caja = await Cajas.findByPk(id);

        if (caja) {
            await caja.update(body);
            res.json({
                msg: 'La caja fue actualizada con éxito'
            });
        } else {
            res.status(404).json({
                msg: `No existe una caja con el id ${id}`
            });
        }
    } catch (error) {
        console.log(error);
        res.json({
            msg: `Ocurrió un error al actualizar la caja, comuníquese con soporte`
        });
    }
};
