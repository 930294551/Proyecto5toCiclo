// controllers/ventas.ts

import { Request, Response } from 'express';
import Ventas from '../models/ventas';

// Función para obtener todas las ventas
export const getVentas = async (req: Request, res: Response) => {
    const ventas = await Ventas.findAll();
    res.json(ventas);
};

// Función para obtener una venta por su ID
export const getVenta = async (req: Request, res: Response) => {
    const { id } = req.params;
    const venta = await Ventas.findByPk(id);

    if (venta) {
        res.json(venta);
    } else {
        res.status(404).json({
            msg: `No existe una venta con el id ${id}`
        });
    }
};

// Función para eliminar una venta por su ID
export const deleteVenta = async (req: Request, res: Response) => {
    const { id } = req.params;
    const venta = await Ventas.findByPk(id);

    if (!venta) {
        res.status(404).json({
            msg: `No existe una venta con el id ${id}`
        });
    } else {
        await venta.destroy();
        res.json({
            msg: 'La venta fue eliminada con éxito'
        });
    }
};

// Función para crear una nueva venta
export const postVenta = async (req: Request, res: Response) => {
    const { body } = req;

    try {
        await Ventas.create(body);
        res.json({
            msg: `La venta fue agregada con éxito`
        });
    } catch (error) {
        console.log(error);
        res.json({
            msg: `Ocurrió un error al agregar la venta, comuníquese con soporte`
        });
    }
};

// Función para actualizar una venta por su ID
export const updateVenta = async (req: Request, res: Response) => {
    const { body } = req;
    const { id } = req.params;

    try {
        const venta = await Ventas.findByPk(id);

        if (venta) {
            await venta.update(body);
            res.json({
                msg: 'La venta fue actualizada con éxito'
            });
        } else {
            res.status(404).json({
                msg: `No existe una venta con el id ${id}`
            });
        }
    } catch (error) {
        console.log(error);
        res.json({
            msg: `Ocurrió un error al actualizar la venta, comuníquese con soporte`
        });
    }
};
