import { Request, Response } from "express";
import Campanias from "../models/campania";

export const getCampanias = async (req: Request, res: Response) => {
  const campanias = await Campanias.findAll();
  res.json(campanias);
};

export const getCampania = async (req: Request, res: Response) => {
  const { id } = req.params;
  const campania = await Campanias.findByPk(id);
  if (campania) {
    res.json(campania);
  } else {
    res.status(404).json({
      msg: `No existe una campaña con el id ${id}`,
    });
  }
};

export const deleteCampania = async (req: Request, res: Response) => {
  const { id } = req.params;
  const campania = await Campanias.findByPk(id);
  if (!campania) {
    res.status(404).json({
      msg: `No existe una campaña con el id ${id}`,
    });
  } else {
    await campania.destroy();
    res.json({
      msg: "La campaña fue eliminada con éxito",
    });
  }
};

export const postCampania = async (req: Request, res: Response) => {
  const { body } = req;
  try {
    const campania_ = await Campanias.create(body);
    res.status(201).json(campania_); 
  } catch (error) {
    console.log(error);
    res.json({
      msg: `Ocurrió un error al agregar la campaña, comuníquese con soporte`,
    });
  }
};

export const updateCampania = async (req: Request, res: Response) => {
  const { body } = req;
  const { id } = req.params;
  try {
    const campania = await Campanias.findByPk(id);

    if (campania) {
      await campania.update(body);
      res.json({
        msg: "La campaña fue actualizada con éxito",
      });
    } else {
      res.status(404).json({
        msg: `No existe una campaña con el id ${id}`,
      });
    }
  } catch (error) {
    console.log(error);
    res.json({
      msg: `Ocurrió un error al actualizar la campaña, comuníquese con soporte`,
    });
  }
};
