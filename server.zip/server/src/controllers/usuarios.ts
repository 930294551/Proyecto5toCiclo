import { Request, Response } from 'express';
import Usuarios from '../models/usuarios';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcrypt';

export const getUsuarios = async (req: Request, res: Response) => {
    const listUsuarios = await Usuarios.findAll()

    res.json(listUsuarios)
}

export const getUsuario = async (req: Request, res: Response) => {
    const { correo } = req.params;
    try {
        const usuario = await Usuarios.findOne({ where: { email: correo } });

        if (usuario) {
            res.json(usuario);
        } else {
            res.status(404).json({
                msg: `No existe un usuario con el correo ${correo}`
            });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({
            msg: 'Ocurrió un error al obtener el usuario, comuníquese con soporte'
        });
    }
}

export const getUsuarioByNameUser = async (req: Request, res: Response) => {
    const { nameuser } = req.params;
    try {
        const usuario = await Usuarios.findOne({ where: { nombreUsuario: nameuser } });

        if (usuario) {
            res.json(usuario);
        } else {
            res.status(404).json({
                msg: `No existe un usuario con el nombre ${nameuser}`
            });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({
            msg: 'Ocurrió un error al obtener el usuario, comuníquese con soporte'
        });
    }
}


export const deleteUsuario = async (req: Request, res: Response) => {
    const { correo } = req.params;
    const usuario = await Usuarios.findOne({ where: { email: correo } });

    if (!usuario) {
        res.status(404).json({
            msg: `No existe un usuario con el correo ${correo}`
        })
    } else {
        await usuario.destroy();
        res.json({
            msg: 'El usuario fue eliminado con éxito!'
        })
    }
}

export const postUsuario = async (req: Request, res: Response) => {
    const { body } = req;

    try {
        const hashedPassword = await bcrypt.hash(body.clave, 10);
        body.clave = hashedPassword;

        await Usuarios.create(body);
        res.json({
            msg: `El usuario fue agregado con éxito!`
        })
    } catch (error) {
        console.log(error);
        res.status(500).json({
            msg: `Upps ocurrió un error, comuníquese con soporte`
        })
    }
}

export const updateUsuario = async (req: Request, res: Response) => {
    const { body } = req;
    const { id } = req.params;

    try {
        const usuario = await Usuarios.findByPk(id);

        if (usuario) {
            // Compare the current password with the new one
            
            const isPasswordDifferent = body.clave && body.clave != usuario.clave;

            if (isPasswordDifferent) {
                console.log("isPasswordDifferent: " + body.clave);
                const hashedPassword = await bcrypt.hash(body.clave, 10);
                console.log("hashedPassword: " +hashedPassword);
                body.clave = hashedPassword;
            } else {
                delete body.clave;
            }

            await usuario.update(body);
            res.json({
                msg: 'El usuario fue actualizado con éxito'
            });
        } else {
            res.status(404).json({
                msg: `No existe un usuario con el id ${id}`
            });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({
            msg: `Upps ocurrió un error, comuníquese con soporte`
        });
    }
};


export const login = async (req: Request, res: Response) => {
    const { nombreUsuario, password } = req.body;
    try {
        const usuario = await Usuarios.findOne({ where: { nombreUsuario: nombreUsuario } });

        if (usuario) {
            const passwordValid = await bcrypt.compare(password, usuario.clave);
            if (passwordValid) {
                const token = jwt.sign({ usuarioId: usuario.usuario_id }, 'secreto', { expiresIn: '1h' });
                res.json({  
                    msg: 'Inicio de sesión exitoso',
                    token,
                    usuario
                });
            } else {
                res.status(401).json({
                    msg: 'Credenciales inválidas'
                });
            }
        } else {
            res.status(404).json({
                msg: 'Usuario no encontrado'
            });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({
            msg: 'Ocurrió un error al iniciar sesión, comuníquese con soporte'
        });
    }
}

export const getUsuarioPorId = async (req: Request, res: Response) => {
    const { id } = req.params;
    try {
        const usuario = await Usuarios.findByPk(id);

        if (usuario) {
            res.json(usuario);
        } else {
            res.status(404).json({
                msg: `No existe un usuario con el ID ${id}`
            });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({
            msg: 'Ocurrió un error al obtener el usuario, comuníquese con soporte'
        });
    }
}
