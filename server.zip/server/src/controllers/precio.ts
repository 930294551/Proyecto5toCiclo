// controllers/precios.ts

import { Request, Response } from 'express';
import Precio from '../models/precio';

export const getPrecios = async (req: Request, res: Response) => {
    const precios = await Precio.findAll();
    res.json(precios);
};

export const getPrecio = async (req: Request, res: Response) => {
    const { id } = req.params;
    const precio = await Precio.findByPk(id);

    if (precio) {
        res.json(precio);
    } else {
        res.status(404).json({
            msg: `No existe un precio con el id ${id}`
        });
    }
};

export const deletePrecio = async (req: Request, res: Response) => {
    const { id } = req.params;
    const precio = await Precio.findByPk(id);

    if (!precio) {
        res.status(404).json({
            msg: `No existe un precio con el id ${id}`
        });
    } else {
        await precio.destroy();
        res.json({
            msg: 'El precio fue eliminado con éxito'
        });
    }
};

export const postPrecio = async (req: Request, res: Response) => {
    const { body } = req;

    try {
        const precio = await Precio.create(body);
        res.status(201).json(precio); 
    } catch (error) {
        console.log(error);
        res.json({
            msg: `Ocurrió un error al agregar el precio, comuníquese con soporte`
        });
    }
};

export const updatePrecio = async (req: Request, res: Response) => {
    const { body } = req;
    const { id } = req.params;

    try {
        const precio = await Precio.findByPk(id);

        if (precio) {
            await precio.update(body);
            res.json({
                msg: 'El precio fue actualizado con éxito'
            });
        } else {
            res.status(404).json({
                msg: `No existe un precio con el id ${id}`
            });
        }
    } catch (error) {
        console.log(error);
        res.json({
            msg: `Ocurrió un error al actualizar el precio, comuníquese con soporte`
        });
    }
};
