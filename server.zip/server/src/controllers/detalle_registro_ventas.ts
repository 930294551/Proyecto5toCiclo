// controllers/detalle_registro_ventas.ts

import { Request, Response } from 'express';
import DetalleRegistroVentas from '../models/detalle_registro_ventas';

export const getDetalleRegistroVentas = async (req: Request, res: Response) => {
    try {
        const detalleRegistroVentas = await DetalleRegistroVentas.findAll();
        res.json(detalleRegistroVentas);
    } catch (error) {
        console.error(error);
        res.status(500).json({ msg: 'Internal server error' });
    }
};

export const getDetalleRegistroVenta = async (req: Request, res: Response) => {
    const { id } = req.params;
    try {
        const detalleRegistroVenta = await DetalleRegistroVentas.findByPk(id);

        if (detalleRegistroVenta) {
            res.json(detalleRegistroVenta);
        } else {
            res.status(404).json({ msg: `No existe un detalle de registro de ventas con el id ${id}` });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ msg: 'Internal server error' });
    }
};

export const deleteDetalleRegistroVenta = async (req: Request, res: Response) => {
    const { id } = req.params;
    try {
        const detalleRegistroVenta = await DetalleRegistroVentas.findByPk(id);

        if (!detalleRegistroVenta) {
            res.status(404).json({ msg: `No existe un detalle de registro de ventas con el id ${id}` });
        } else {
            await detalleRegistroVenta.destroy();
            res.json({ msg: 'El detalle de registro de ventas fue eliminado con éxito' });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ msg: 'Internal server error' });
    }
};

export const postDetalleRegistroVenta = async (req: Request, res: Response) => {
    const { body } = req;

    try {
        await DetalleRegistroVentas.create(body);
        res.json({ msg: `El detalle de registro de ventas fue agregado con éxito` });
    } catch (error) {
        console.error(error);
        res.status(500).json({ msg: 'Internal server error' });
    }
};

export const updateDetalleRegistroVenta = async (req: Request, res: Response) => {
    const { body } = req;
    const { id } = req.params;

    try {
        const detalleRegistroVenta = await DetalleRegistroVentas.findByPk(id);

        if (detalleRegistroVenta) {
            await detalleRegistroVenta.update(body);
            res.json({ msg: 'El detalle de registro de ventas fue actualizado con éxito' });
        } else {
            res.status(404).json({ msg: `No existe un detalle de registro de ventas con el id ${id}` });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ msg: 'Internal server error' });
    }
};
