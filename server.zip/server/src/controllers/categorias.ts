// controllers/categorias.ts

import { Request, Response } from 'express';
import Categorias from '../models/categorias';

export const getCategorias = async (req: Request, res: Response) => {
    const categorias = await Categorias.findAll();
    res.json(categorias);
};

export const getCategoria = async (req: Request, res: Response) => {
    const { id } = req.params;
    const categoria = await Categorias.findByPk(id);

    if (categoria) {
        res.json(categoria);
    } else {
        res.status(404).json({
            msg: `No existe una categoría con el id ${id}`
        });
    }
};

export const deleteCategoria = async (req: Request, res: Response) => {
    const { id } = req.params;
    const categoria = await Categorias.findByPk(id);

    if (!categoria) {
        res.status(404).json({
            msg: `No existe una categoría con el id ${id}`
        });
    } else {
        await categoria.destroy();
        res.json({
            msg: 'La categoría fue eliminada con éxito'
        });
    }
};

export const postCategoria = async (req: Request, res: Response) => {
    const { body } = req;

    try {
        const categoria = await Categorias.create(body);
        res.status(201).json(categoria); 
    } catch (error) {
        console.log(error);
        res.status(500).json({
            msg: `Ocurrió un error al agregar la categoría, comuníquese con soporte`
        });
    }
};

export const updateCategoria = async (req: Request, res: Response) => {
    const { body } = req;
    const { id } = req.params;

    try {
        const categoria = await Categorias.findByPk(id);

        if (categoria) {
            await categoria.update(body);
            res.json({
                msg: 'La categoría fue actualizada con éxito'
            });
        } else {
            res.status(404).json({
                msg: `No existe una categoría con el id ${id}`
            });
        }
    } catch (error) {
        console.log(error);
        res.json({
            msg: `Ocurrió un error al actualizar la categoría, comuníquese con soporte`
        });
    }
};
