import { Request, Response } from 'express';
import Marcas from '../models/marca'; // Importa el modelo de Marcas

export const getMarcas = async (req: Request, res: Response) => {
  const marcas = await Marcas.findAll(); // Busca todas las marcas
  res.json(marcas); // Envía las marcas en formato JSON
};

export const getMarca = async (req: Request, res: Response) => {
  const { id } = req.params; // Obtiene el id de la marca de los parámetros
  const marca = await Marcas.findByPk(id); // Busca la marca por id

  if (marca) {
    res.json(marca); // Envía la marca en formato JSON
  } else {
    res.status(404).json({ // Si no se encuentra la marca, envía un error 404
      msg: `No existe una marca con el id ${id}`
    });
  }
};

export const deleteMarca = async (req: Request, res: Response) => {
  const { id } = req.params; // Obtiene el id de la marca de los parámetros
  const marca = await Marcas.findByPk(id); // Busca la marca por id

  if (!marca) {
    res.status(404).json({ // Si no se encuentra la marca, envía un error 404
      msg: `No existe una marca con el id ${id}`
    });
  } else {
    await marca.destroy(); // Elimina la marca
    res.json({ // Envía un mensaje de éxito
      msg: 'La marca fue eliminada con éxito'
    });
  }
};

export const postMarca = async (req: Request, res: Response) => {
  const { body } = req; // Obtiene los datos de la marca del cuerpo de la solicitud

  try {
    const marca_ = await Marcas.create(body);
    res.status(201).json(marca_); 
  } catch (error) {
    console.log(error); // Registra el error en la consola
    res.json({ // Envía un mensaje de error
      msg: `Ocurrió un error al agregar la marca, comuníquese con soporte`
    });
  }
};

export const updateMarca = async (req: Request, res: Response) => {
  const { body } = req; // Obtiene los datos actualizados de la marca del cuerpo de la solicitud
  const { id } = req.params; // Obtiene el id de la marca de los parámetros

  try {
    const marca = await Marcas.findByPk(id); // Busca la marca por id

    if (marca) {
      await marca.update(body); // Actualiza la marca con los datos proporcionados
      res.json({ // Envía un mensaje de éxito
        msg: 'La marca fue actualizada con éxito'
      });
    } else {
      res.status(404).json({ // Si no se encuentra la marca, envía un error 404
        msg: `No existe una marca con el id ${id}`
      });
    }
  } catch (error) {
    console.log(error); // Registra el error en la consola
    res.json({ // Envía un mensaje de error
      msg: `Ocurrió un error al actualizar la marca, comuníquese con soporte`
    });
  }
};
