import { Request, Response } from 'express';
import Productos from '../models/productos';

export const getProductos = async (req: Request, res: Response) => {
    const listProductos = await Productos.findAll();

    res.json(listProductos);
};

export const getProducto = async (req: Request, res: Response) => {
    const { id } = req.params;
    const producto = await Productos.findByPk(id);

    if (producto) {
        res.json(producto);
    } else {
        res.status(404).json({
            msg: `No existe un producto con el id ${id}`
        });
    }
};

export const deleteProducto = async (req: Request, res: Response) => {
    const { id } = req.params;
    const producto = await Productos.findByPk(id);

    if (!producto) {
        res.status(404).json({
            msg: `No existe un producto con el id ${id}`
        });
    } else {
        await producto.destroy();
        res.json({
            msg: 'El producto fue eliminado con éxito'
        });
    }
};

export const postProducto = async (req: Request, res: Response) => {
    const { body } = req;

    try {
        await Productos.create(body);
        res.json({
            msg: `El producto fue agregado con éxito`
        });
    } catch (error) {
        console.log(error);
        res.json({
            msg: `Ocurrió un error al agregar el producto, comuníquese con soporte`
        });
    }
};

export const updateProducto = async (req: Request, res: Response) => {
    const { body } = req;
    const { id } = req.params;

    try {
        const producto = await Productos.findByPk(id);

        if (producto) {
            await producto.update(body);
            res.json({
                msg: 'El producto fue actualizado con éxito'
            });
        } else {
            res.status(404).json({
                msg: `No existe un producto con el id ${id}`
            });
        }
    } catch (error) {
        console.log(error);
        res.json({
            msg: `Ocurrió un error al actualizar el producto, comuníquese con soporte`
        });
    }
};
