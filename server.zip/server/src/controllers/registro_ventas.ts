// controllers/registro_ventas.ts

import { Request, Response } from 'express';
import RegistroVentas from '../models/registro_ventas';

export const getRegistroVentas = async (req: Request, res: Response) => {
    try {
        const registroVentas = await RegistroVentas.findAll();
        res.json(registroVentas);
    } catch (error) {
        console.error(error);
        res.status(500).json({ msg: 'Internal server error' });
    }
};

export const getRegistroVenta = async (req: Request, res: Response) => {
    const { id } = req.params;
    try {
        const registroVenta = await RegistroVentas.findByPk(id);

        if (registroVenta) {
            res.json(registroVenta);
        } else {
            res.status(404).json({ msg: `No existe un registro de ventas con el id ${id}` });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ msg: 'Internal server error' });
    }
};

export const deleteRegistroVenta = async (req: Request, res: Response) => {
    const { id } = req.params;
    try {
        const registroVenta = await RegistroVentas.findByPk(id);

        if (!registroVenta) {
            res.status(404).json({ msg: `No existe un registro de ventas con el id ${id}` });
        } else {
            await registroVenta.destroy();
            res.json({ msg: 'El registro de ventas fue eliminado con éxito' });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ msg: 'Internal server error' });
    }
};

export const postRegistroVenta = async (req: Request, res: Response) => {
    const { body } = req;

    try {
        const createFull = await RegistroVentas.create(body);
        res.status(201).json(createFull); 
    } catch (error) {
        console.error(error);
        res.status(500).json({ msg: 'Internal server error' });
    }
};

export const updateRegistroVenta = async (req: Request, res: Response) => {
    const { body } = req;
    const { id } = req.params;

    try {
        const registroVenta = await RegistroVentas.findByPk(id);

        if (registroVenta) {
            await registroVenta.update(body);
            res.json({ msg: 'El registro de ventas fue actualizado con éxito' });
        } else {
            res.status(404).json({ msg: `No existe un registro de ventas con el id ${id}` });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ msg: 'Internal server error' });
    }
};
