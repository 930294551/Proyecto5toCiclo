import { Request, Response } from 'express';
import Clientes from '../models/clientes';

export const getClientes = async (req: Request, res: Response) => {
    const listClientes = await Clientes.findAll()

    res.json(listClientes)
}

export const getCliente = async (req: Request, res: Response) => {
    const { id } = req.params;
    const clientes = await Clientes.findByPk(id);

    if (clientes) {
        res.json(clientes)
    } else {
        res.status(404).json({
            msg: `No existe un registro con el id ${id}`
        })
    }
}

export const deleteClientes = async (req: Request, res: Response) => {
    const { id } = req.params;
    const clientes = await Clientes.findByPk(id);

    if (!clientes) {
        res.status(404).json({
            msg: `No existe un registro con el id ${id}`
        })
    } else {
        await clientes.destroy();
        res.json({
            msg: 'El registro fue eliminado con exito!'
        })
    }

}

export const postClientes = async (req: Request, res: Response) => {
    const { body } = req;

    try {
        await Clientes.create(body);

        res.json({
            msg: `El registro fue agregado con exito!`
        })
    } catch (error) {
        res.json({
            msg: `Upps ocurrio un error, comuniquese con soporte`
        })
    }
}

export const updateClientes = async (req: Request, res: Response) => {
    const { body } = req;
    const { id } = req.params;

    try {

        const clientes = await Clientes.findByPk(id);

    if(clientes) {
        await clientes.update(body);
        res.json({
            msg: 'El registro fue actualziado con exito'
        })

    } else {
        res.status(404).json({
            msg: `No existe un registro con el id ${id}`
        })
    }
        
    } catch (error) {
        console.log(error);
        res.json({
            msg: `Upps ocurrio un error, comuniquese con soporte`
        })
    }

    
}