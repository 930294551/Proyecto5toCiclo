// controllers/unidadesMedida.ts

import { Request, Response } from 'express';
import UnidadesMedida from '../models/unidadesMedida';

export const getUnidadesMedida = async (req: Request, res: Response) => {
    const unidadesMedida = await UnidadesMedida.findAll();
    res.json(unidadesMedida);
};

export const getUnidadMedida = async (req: Request, res: Response) => {
    const { id } = req.params;
    const unidadMedida = await UnidadesMedida.findByPk(id);

    if (unidadMedida) {
        res.json(unidadMedida);
    } else {
        res.status(404).json({
            msg: `No existe una unidad de medida con el id ${id}`
        });
    }
};

export const deleteUnidadMedida = async (req: Request, res: Response) => {
    const { id } = req.params;
    const unidadMedida = await UnidadesMedida.findByPk(id);

    if (!unidadMedida) {
        res.status(404).json({
            msg: `No existe una unidad de medida con el id ${id}`
        });
    } else {
        await unidadMedida.destroy();
        res.json({
            msg: 'La unidad de medida fue eliminada con éxito'
        });
    }
};

export const postUnidadMedida = async (req: Request, res: Response) => {
    const { body } = req;

    try {
        const unidadMedida = await UnidadesMedida.create(body);
        res.status(201).json(unidadMedida); 
    } catch (error) {
        console.log(error);
        res.json({
            msg: `Ocurrió un error al agregar la unidad de medida, comuníquese con soporte`
        });
    }
};

export const updateUnidadMedida = async (req: Request, res: Response) => {
    const { body } = req;
    const { id } = req.params;

    try {
        const unidadMedida = await UnidadesMedida.findByPk(id);

        if (unidadMedida) {
            await unidadMedida.update(body);
            res.json({
                msg: 'La unidad de medida fue actualizada con éxito'
            });
        } else {
            res.status(404).json({
                msg: `No existe una unidad de medida con el id ${id}`
            });
        }
    } catch (error) {
        console.log(error);
        res.json({
            msg: `Ocurrió un error al actualizar la unidad de medida, comuníquese con soporte`
        });
    }
};
